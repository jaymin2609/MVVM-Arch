package com.ts.ts_demo.rootmanager

import android.content.Context
import com.ts.ts_demo.Application

object ResourceProvider {

    val applicationContext: Context by lazy {
        Application.instance.applicationContext
    }


}