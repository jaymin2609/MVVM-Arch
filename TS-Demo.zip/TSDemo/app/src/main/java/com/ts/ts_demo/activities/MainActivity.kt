package com.ts.ts_demo.activities

import android.content.Context
import android.os.Bundle
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.ts.ts_demo.extensions.toastShort
import com.ts.ts_demo.rootmanager.Status
import com.ts.ts_demo.R
import com.ts.ts_demo.adapters.UserListAdapter
import com.ts.ts_demo.databinding.ActivityMainBinding
import com.ts.ts_demo.db.entity.UserEntity
import com.ts.ts_demo.rootmanager.BaseActivity
import com.ts.ts_demo.utilities.LogUtils
import com.ts.ts_demo.utilities.ProgressBar
import com.ts.ts_demo.viewmodels.UserListViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job

@AndroidEntryPoint
class MainActivity : BaseActivity() {
    private val classTag = MainActivity::class.java.simpleName
    private lateinit var binding: ActivityMainBinding
    lateinit var mContext: Context
    private val coroutineScope = CoroutineScope(Dispatchers.Main + Job())
    private val userListViewModel: UserListViewModel by viewModels()
    private lateinit var userListAdapter: UserListAdapter
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        try {
            super.onCreate(savedInstanceState)
            binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
            mContext = this
            initViewModel()
            initViews()
        } catch (e: Exception) {
            LogUtils.logE(classTag, e)
        }
    }
    private fun initViewModel() {
        binding.viewModel = userListViewModel
        binding.lifecycleOwner = this
    }

    private fun initViews() {
        progressBar = ProgressBar(context = mContext)
        binding.rvUserList.layoutManager = LinearLayoutManager(mContext)
        userListAdapter =
            UserListAdapter { listItemClicked(it) }
        binding.rvUserList.adapter = userListAdapter
        bindObserver()
    }

    private fun bindObserver() {
        /*Observe data from Room database*/
        userListViewModel.userListLocal.observe(this, Observer { userList ->
//            userListAdapter.setList(userList)
//            userListAdapter.notifyDataSetChanged()
        })
        /*Observe data from API call*/
        userListViewModel.userList.observe(this, Observer { userList ->
            when (userList.status) {
                Status.SUCCESS -> {
                    userListAdapter.setList(userList.data!!)
                    userListAdapter.notifyDataSetChanged()
                }
                Status.ERROR -> {

                }
            }

        })

        /*Observe data from viewModel for loader*/
        userListViewModel.dataLoading.observe(this, Observer {
            if (it) {
//                progressBar.showLoader()
            } else {
//                progressBar.hideLoader()
            }
        })
    }
    private fun listItemClicked(userEntity: UserEntity) {
        mContext.toastShort("Selected User Name : ${userEntity.name} and Age : ${userEntity.age}")
    }
}