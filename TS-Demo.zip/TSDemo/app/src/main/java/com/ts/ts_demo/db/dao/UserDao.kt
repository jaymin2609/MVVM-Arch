package com.ts.ts_demo.db.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Query
import com.ts.ts_demo.db.entity.UserEntity
import com.ts.ts_demo.rootmanager.BaseDao
import com.ts.ts_demo.utilities.DBConstant.TB_COL_NAME
import com.ts.ts_demo.utilities.DBConstant.TB_USERS

@Dao
interface UserDao : BaseDao<UserEntity> {

    @Query("SELECT * FROM $TB_USERS")
    fun getUserData(): LiveData<List<UserEntity>>

    @Query("SELECT * FROM $TB_USERS where $TB_COL_NAME  LIKE:name")
    fun getUserDataNonLive(name: String): UserEntity?


}