package com.ts.ts_demo.utilities

const val SPLASH_TIME_OUT = 5000
const val DEVICE_PLATFORM: String = "android"
const val APP_MODULE: String = "ETE"
const val CONNECTION_TIMEOUT: Long = 3

/*Common*/
const val PREF_TS_DEMO: String = "PREF_TS_DEMO"
const val PREF_KEY_AUTH: String = "oAuthkey"
var TAG = "TAG"

const val REQUEST_CHECK_SETTINGS = 0x1
const val DD_MM_YYYY_format = "dd/MM/yyyy"












