package com.ts.ts_demo.rootmanager

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.ts.ts_demo.BuildConfig
import com.ts.ts_demo.db.dao.UserDao
import com.ts.ts_demo.db.entity.UserEntity

@Database(
    entities = [UserEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao

    companion object {
        @Volatile
        private var appDatabase: AppDatabase? = null
        private var databaseName = "TS_Demo_DB"


        fun getInstance(context: Context): AppDatabase {
            val tempInstance = appDatabase
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                databaseName += if (BuildConfig.FLAVOR.equals("qa", ignoreCase = false)) {
                    "_QA.db"
                } else {
                    "_PROD.db"
                }
                val instance = Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, databaseName
                )
                    .build()
                appDatabase = instance
                return instance
            }
        }
    }
}