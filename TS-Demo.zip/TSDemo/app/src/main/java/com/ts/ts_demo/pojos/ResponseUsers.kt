package com.ts.ts_demo.pojos

import com.ts.ts_demo.db.entity.UserEntity


data class ResponseUsers(
    val userList: List<UserEntity>
)